<?php
declare(strict_types=1);

function student_record(PDO $db, int $id): array
{
    $statement=$db->prepare("SELECT s.*,TRIM(CONCAT(s.firstname,' ',COALESCE(CONCAT(s.middlename,' '),''),s.lastname)) full_name FROM tblstudents s WHERE s.stud_auto=:id LIMIT 1");$statement->execute(['id'=>$id]);$student=$statement->fetch();if(!$student)fail('Student not found.',404);return$student;
}

function student_rows(PDO $db): void
{
    current_account($db);need_tables($db,['tblstudents']);$year=active_year($db);$yearId=max(0,(int)($_GET['academic_year_id']??$year['id']));$search=trim((string)($_GET['search']??''));$status=max(0,(int)($_GET['status_id']??0));$grade=max(0,(int)($_GET['grade_id']??0));$page=max(1,(int)($_GET['page']??1));$per=min(100,max(10,(int)($_GET['per_page']??25)));$offset=($page-1)*$per;
    $enroll=table_present($db,'tblstudent_enrollments')&&$yearId>0;$gradeExpr=$enroll?'COALESCE(e.gradeid,s.gradeid)':'s.gradeid';$levelExpr=$enroll?'COALESCE(e.levelid,s.levelid)':'s.levelid';$sectionExpr=$enroll?'COALESCE(e.secid,s.secid)':'s.secid';$statusExpr=$enroll?'COALESCE(e.status,s.status)':'s.status';
    $joins=$enroll?' LEFT JOIN tblstudent_enrollments e ON e.stud_auto=s.stud_auto AND e.ayid=:year ':'';$params=$enroll?['year'=>$yearId]:[];
    if(table_present($db,'tblgradelevel'))$joins.=" LEFT JOIN tblgradelevel g ON g.gradeid={$gradeExpr} ";if(table_present($db,'tbllevels'))$joins.=" LEFT JOIN tbllevels l ON l.levelid={$levelExpr} ";if($enroll&&table_present($db,'tblschedules'))$joins.=' LEFT JOIN tblschedules sc ON sc.scheduleid=e.scheduleid ';if(table_present($db,'tblsectioning'))$joins.=" LEFT JOIN tblsectioning sec ON sec.secid={$sectionExpr} ";if(table_present($db,'tblstudent_status'))$joins.=" LEFT JOIN tblstudent_status st ON st.status_id={$statusExpr} ";
    $where=['1=1'];if($search!==''){$where[]="(s.studentid LIKE :search OR s.firstname LIKE :search OR s.lastname LIKE :search OR CONCAT(s.firstname,' ',s.lastname) LIKE :search)";$params['search']='%'.$search.'%';}if($status>0){$where[]="{$statusExpr}=:status";$params['status']=$status;}if($grade>0){$where[]="{$gradeExpr}=:grade";$params['grade']=$grade;}$condition=implode(' AND ',$where);
    $select=["s.stud_auto","s.studentid","s.firstname","s.middlename","s.lastname","TRIM(CONCAT(s.firstname,' ',COALESCE(CONCAT(s.middlename,' '),''),s.lastname)) full_name","s.active_mobile_number","s.dob","s.profile_image","s.family_id","{$gradeExpr} gradeid","{$levelExpr} levelid","{$sectionExpr} secid","{$statusExpr} status_id",$enroll?'e.scheduleid':'NULL scheduleid',$enroll?'e.enroll_date':'NULL enroll_date',table_present($db,'tblgradelevel')?'g.grade_level_desc grade':'NULL grade',table_present($db,'tbllevels')?'l.level_code level':'NULL level',$enroll&&table_present($db,'tblschedules')?'sc.schedule_name schedule':'NULL schedule',table_present($db,'tblsectioning')?'sec.sec_name section':'NULL section',table_present($db,'tblstudent_status')?'st.status_name status':'NULL status'];
    $count=$db->prepare("SELECT COUNT(DISTINCT s.stud_auto) FROM tblstudents s {$joins} WHERE {$condition}");foreach($params as$key=>$value)$count->bindValue(':'.$key,$value,is_int($value)?PDO::PARAM_INT:PDO::PARAM_STR);$count->execute();$total=(int)$count->fetchColumn();
    $statement=$db->prepare('SELECT '.implode(',',$select)." FROM tblstudents s {$joins} WHERE {$condition} ORDER BY s.lastname,s.firstname LIMIT :limit OFFSET :offset");foreach($params as$key=>$value)$statement->bindValue(':'.$key,$value,is_int($value)?PDO::PARAM_INT:PDO::PARAM_STR);$statement->bindValue(':limit',$per,PDO::PARAM_INT);$statement->bindValue(':offset',$offset,PDO::PARAM_INT);$statement->execute();
    respond($statement->fetchAll(),200,['page'=>$page,'per_page'=>$per,'total'=>$total,'last_page'=>max(1,(int)ceil($total/$per)),'academic_year'=>$year]);
}

function student_details(PDO $db,int$id):void
{
    current_account($db);need_tables($db,['tblstudents']);$student=student_record($db,$id);$enrollments=[];$payments=[];
    if(table_present($db,'tblstudent_enrollments')){$joins=' LEFT JOIN tblacademic_years ay ON ay.acayearid=e.ayid ';$joins.=table_present($db,'tblgradelevel')?' LEFT JOIN tblgradelevel g ON g.gradeid=e.gradeid ':'';$joins.=table_present($db,'tbllevels')?' LEFT JOIN tbllevels l ON l.levelid=e.levelid ':'';$joins.=table_present($db,'tblschedules')?' LEFT JOIN tblschedules sc ON sc.scheduleid=e.scheduleid ':'';$joins.=table_present($db,'tblsectioning')?' LEFT JOIN tblsectioning sec ON sec.secid=e.secid ':'';$joins.=table_present($db,'tblstudent_status')?' LEFT JOIN tblstudent_status st ON st.status_id=e.status ':'';$select='e.*,ay.ay academic_year';$select.=table_present($db,'tblgradelevel')?',g.grade_level_desc grade':',NULL grade';$select.=table_present($db,'tbllevels')?',l.level_code level':',NULL level';$select.=table_present($db,'tblschedules')?',sc.schedule_name schedule':',NULL schedule';$select.=table_present($db,'tblsectioning')?',sec.sec_name section':',NULL section';$select.=table_present($db,'tblstudent_status')?',st.status_name status_name':',NULL status_name';$statement=$db->prepare("SELECT {$select} FROM tblstudent_enrollments e {$joins} WHERE e.stud_auto=:id ORDER BY ay.acayearid DESC");$statement->execute(['id'=>$id]);$enrollments=$statement->fetchAll();}
    if(table_present($db,'tblpayments_history')){$join=table_present($db,'tblpayments')?'LEFT JOIN tblpayments p ON p.payid=ph.payid':'';$label=table_present($db,'tblpayments')?'p.paydescription':'NULL';$statement=$db->prepare("SELECT ph.*,{$label} fee_description FROM tblpayments_history ph {$join} WHERE ph.studentid=:student ORDER BY ph.date_paid DESC,ph.payhist_id DESC LIMIT 100");$statement->execute(['student'=>$student['studentid']]);$payments=$statement->fetchAll();}
    respond(['student'=>$student,'enrollments'=>$enrollments,'payments'=>$payments]);
}

function student_values(array$body,bool$partial=false):array
{
    $fields=['studentid','firstname','middlename','lastname','active_mobile_number','dob','family_id','gradeid','levelid','secid','status'];$values=[];foreach($fields as$field)if(array_key_exists($field,$body))$values[$field]=is_string($body[$field])?trim($body[$field]):$body[$field];
    if(!$partial||array_key_exists('studentid',$values))if(empty($values['studentid'])||string_length((string)$values['studentid'])>50)fail('A student ID of at most 50 characters is required.',422);foreach(['firstname','lastname']as$field)if(!$partial||array_key_exists($field,$values))if(empty($values[$field])||string_length((string)$values[$field])>100)fail(ucfirst($field).' is required and must not exceed 100 characters.',422);
    if(isset($values['dob'])&&$values['dob']!==''){$date=DateTime::createFromFormat('!Y-m-d',(string)$values['dob']);if($date===false||$date->format('Y-m-d')!==$values['dob'])fail('Date of birth must be a valid YYYY-MM-DD date.',422);}foreach(['family_id','gradeid','levelid','secid','status']as$field)if(array_key_exists($field,$values))$values[$field]=$values[$field]===''||$values[$field]===null?null:(int)$values[$field];return$values;
}

function create_student(PDO$db):void
{
    current_account($db,['Administrator']);need_tables($db,['tblstudents']);$body=input();$v=student_values($body);$year=(int)($body['academic_year_id']??active_year($db)['id']);$status=(int)($v['status']??1);
    try{$db->beginTransaction();$db->prepare('INSERT INTO tblstudents (studentid,firstname,middlename,lastname,active_mobile_number,dob,family_id,gradeid,levelid,secid,status,ay,created_at) VALUES (:studentid,:firstname,:middlename,:lastname,:mobile,:dob,:family,:grade,:level,:section,:status,:year,NOW())')->execute(['studentid'=>$v['studentid'],'firstname'=>$v['firstname'],'middlename'=>$v['middlename']??null,'lastname'=>$v['lastname'],'mobile'=>$v['active_mobile_number']??null,'dob'=>($v['dob']??'')?:null,'family'=>$v['family_id']??null,'grade'=>$v['gradeid']??null,'level'=>$v['levelid']??null,'section'=>$v['secid']??null,'status'=>$status,'year'=>(string)$year]);$id=(int)$db->lastInsertId();if(table_present($db,'tblstudent_enrollments')&&$year>0&&!empty($v['gradeid']))$db->prepare('INSERT INTO tblstudent_enrollments (stud_auto,ayid,gradeid,levelid,enroll_date,scheduleid,secid,status,created_at,updated_at) VALUES (:student,:year,:grade,:level,:date,:schedule,:section,:status,NOW(),NOW())')->execute(['student'=>$id,'year'=>$year,'grade'=>$v['gradeid'],'level'=>$v['levelid']??null,'date'=>($body['enroll_date']??'')?:null,'schedule'=>empty($body['scheduleid'])?null:(int)$body['scheduleid'],'section'=>$v['secid']??null,'status'=>$status]);$db->commit();}
    catch(PDOException$e){if($db->inTransaction())$db->rollBack();if((string)$e->getCode()==='23000')fail('The student ID already exists or a selected value is invalid.',409);throw$e;}respond(student_record($db,$id),201);
}

function update_student(PDO$db,int$id):void
{
    current_account($db,['Administrator']);student_record($db,$id);$values=student_values(input(),true);if($values===[])fail('At least one student field is required.',422);$set=implode(',',array_map(function(string$field):string{return"`{$field}`=:{$field}";},array_keys($values)));$values['_id']=$id;try{$db->prepare("UPDATE tblstudents SET {$set} WHERE stud_auto=:_id")->execute($values);}catch(PDOException$e){if((string)$e->getCode()==='23000')fail('The student ID already exists or a selected value is invalid.',409);throw$e;}respond(student_record($db,$id));
}

function enroll_student(PDO$db,int$id):void
{
    current_account($db,['Administrator']);need_tables($db,['tblstudents','tblstudent_enrollments']);student_record($db,$id);$body=input();$year=(int)($body['academic_year_id']??0);$grade=(int)($body['gradeid']??0);if($year<1||$grade<1)fail('Academic year and grade are required.',422);$db->prepare('INSERT INTO tblstudent_enrollments (stud_auto,ayid,gradeid,levelid,enroll_date,scheduleid,secid,status,created_at,updated_at) VALUES (:student,:year,:grade,:level,:date,:schedule,:section,:status,NOW(),NOW()) ON DUPLICATE KEY UPDATE gradeid=VALUES(gradeid),levelid=VALUES(levelid),enroll_date=VALUES(enroll_date),scheduleid=VALUES(scheduleid),secid=VALUES(secid),status=VALUES(status),updated_at=NOW()')->execute(['student'=>$id,'year'=>$year,'grade'=>$grade,'level'=>empty($body['levelid'])?null:(int)$body['levelid'],'date'=>empty($body['enroll_date'])?null:$body['enroll_date'],'schedule'=>empty($body['scheduleid'])?null:(int)$body['scheduleid'],'section'=>empty($body['secid'])?null:(int)$body['secid'],'status'=>max(1,(int)($body['status']??1))]);respond(['enrolled'=>true]);
}

function delete_student(PDO$db,int$id):void
{
    current_account($db,['Administrator']);$student=student_record($db,$id);if((input()['confirmation']??'')!==$student['studentid'])fail('Enter the exact student ID as confirmation.',422);try{$db->beginTransaction();if(table_present($db,'tbltransaction_logs'))$db->prepare('DELETE FROM tbltransaction_logs WHERE studentid=:student')->execute(['student'=>$student['studentid']]);if(table_present($db,'tblpayments_history'))$db->prepare('DELETE FROM tblpayments_history WHERE studentid=:student')->execute(['student'=>$student['studentid']]);if(table_present($db,'tblstudent_enrollments'))$db->prepare('DELETE FROM tblstudent_enrollments WHERE stud_auto=:id')->execute(['id'=>$id]);$db->prepare('DELETE FROM tblstudents WHERE stud_auto=:id')->execute(['id'=>$id]);$db->commit();}catch(Throwable$e){if($db->inTransaction())$db->rollBack();throw$e;}respond(['deleted'=>true]);
}

function upload_student_image(PDO$db,int$id):void
{
    current_account($db,['Administrator']);student_record($db,$id);if(!isset($_FILES['image'])||!is_array($_FILES['image']))fail('An image file is required.',422);$file=$_FILES['image'];if((int)($file['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK||(int)($file['size']??0)>5*1024*1024)fail('The image failed or exceeds 5 MB.',422);$tmp=(string)($file['tmp_name']??'');$info=$tmp!==''?@getimagesize($tmp):false;$allowed=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];$mime=is_array($info)?(string)($info['mime']??''):'';if(!isset($allowed[$mime]))fail('Only JPG, PNG, and WEBP images are accepted.',422);$name='student-'.$id.'-'.bin2hex(random_bytes(12)).'.'.$allowed[$mime];$directory=dirname(__DIR__).'/storage/uploads';if(!is_dir($directory)&&!mkdir($directory,0775,true))fail('The upload directory is unavailable.',500);if(!move_uploaded_file($tmp,$directory.'/'.$name))fail('The image could not be stored.',500);$db->prepare('UPDATE tblstudents SET profile_image=:image WHERE stud_auto=:id')->execute(['image'=>$name,'id'=>$id]);respond(['filename'=>$name,'image_url'=>rtrim((string)env('APP_URL',''),'/').'/api/student-images/'.rawurlencode($name)]);
}

function serve_student_image(PDO$db,string$filename):void
{
    current_account($db);if(!preg_match('/^[a-zA-Z0-9._-]+$/',$filename))fail('Image not found.',404);$paths=[dirname(__DIR__).'/storage/uploads/'.$filename,dirname(__DIR__,2).'/kumon/profile/'.$filename];$path='';foreach($paths as$candidate)if(is_file($candidate)){$path=$candidate;break;}if($path==='')fail('Image not found.',404);$mime=function_exists('mime_content_type')?(string)mime_content_type($path):'application/octet-stream';header('Content-Type: '.$mime);header('Content-Length: '.filesize($path));header('Cache-Control: private, max-age=3600');readfile($path);exit;
}
