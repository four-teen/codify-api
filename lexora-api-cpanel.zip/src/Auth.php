<?php
declare(strict_types=1);

function url64_encode(string $value): string { return rtrim(strtr(base64_encode($value), '+/', '-_'), '='); }
function url64_decode(string $value): string { $value .= str_repeat('=', (4 - strlen($value) % 4) % 4); return (string)base64_decode(strtr($value, '-_', '+/'), true); }

function signing_key(): string
{
    $key = (string)env('APP_KEY', '');
    if (strlen($key) < 32) fail('The API application key is not configured.', 500);
    return $key;
}

function token_for(array $account): array
{
    $issued = time();
    $expires = $issued + max(900, (int)env('TOKEN_TTL_SECONDS', '28800'));
    $payload = ['sub' => (int)$account['acc_id'], 'iat' => $issued, 'exp' => $expires, 'nonce' => bin2hex(random_bytes(8))];
    $encoded = url64_encode((string)json_encode($payload));
    $signature = url64_encode(hash_hmac('sha256', $encoded, signing_key(), true));
    return ['access_token' => $encoded . '.' . $signature, 'expires_at' => gmdate('c', $expires)];
}

function token_payload(string $token): ?array
{
    $parts = explode('.', $token, 2);
    if (count($parts) !== 2) return null;
    $expected = url64_encode(hash_hmac('sha256', $parts[0], signing_key(), true));
    if (!hash_equals($expected, $parts[1])) return null;
    $payload = json_decode(url64_decode($parts[0]), true);
    if (!is_array($payload) || (int)($payload['exp'] ?? 0) < time() || (int)($payload['sub'] ?? 0) < 1) return null;
    return $payload;
}

function current_account(PDO $db, array $roles = []): array
{
    $payload = token_payload(bearer());
    if (!$payload) fail('Authentication is required.', 401);
    need_tables($db, ['tblaccounts']);
    $statement = $db->prepare('SELECT acc_id, fullname, employee_id, username, role, is_active, last_login FROM tblaccounts WHERE acc_id = :id LIMIT 1');
    $statement->execute(['id' => (int)$payload['sub']]);
    $account = $statement->fetch();
    if (!$account || (int)$account['is_active'] !== 1) fail('This account is unavailable.', 401);
    if ($roles !== [] && !in_array($account['role'], $roles, true)) fail('You do not have permission to perform this action.', 403);
    return $account;
}

function login_limit_file(): string { return dirname(__DIR__) . '/storage/cache/login-' . hash('sha256', request_ip()) . '.json'; }

function guard_login_attempts(): void
{
    $file = login_limit_file();
    if (!is_file($file)) return;
    $state = json_decode((string)file_get_contents($file), true) ?: [];
    if ((int)($state['until'] ?? 0) > time() && (int)($state['attempts'] ?? 0) >= 5) fail('Too many login attempts. Try again later.', 429, ['retry_after' => (int)$state['until'] - time()]);
}

function login_failed(): void
{
    $file = login_limit_file();
    $state = is_file($file) ? (json_decode((string)file_get_contents($file), true) ?: []) : [];
    if ((int)($state['until'] ?? 0) <= time()) $state = ['attempts' => 0, 'until' => time() + 900];
    $state['attempts'] = (int)$state['attempts'] + 1;
    @file_put_contents($file, json_encode($state), LOCK_EX);
}

function login_cleared(): void { $file = login_limit_file(); if (is_file($file)) @unlink($file); }
