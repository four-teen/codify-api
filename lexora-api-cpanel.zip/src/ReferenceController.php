<?php
declare(strict_types=1);

function reference_definitions(): array
{
    return [
        'academic-years' => ['table' => 'tblacademic_years', 'id' => 'acayearid', 'fields' => ['ay'], 'order' => 'CAST(ay AS UNSIGNED), ay'],
        'grades' => ['table' => 'tblgradelevel', 'id' => 'gradeid', 'fields' => ['grade_level_desc'], 'order' => 'grade_level_desc'],
        'levels' => ['table' => 'tbllevels', 'id' => 'levelid', 'fields' => ['level_code', 'sort_order'], 'order' => 'sort_order, level_code'],
        'schedules' => ['table' => 'tblschedules', 'id' => 'scheduleid', 'fields' => ['schedule_name', 'sort_order', 'is_active'], 'order' => 'sort_order, schedule_name'],
        'sections' => ['table' => 'tblsectioning', 'id' => 'secid', 'fields' => ['gradeid', 'sec_name'], 'order' => 'gradeid, sec_name'],
        'statuses' => ['table' => 'tblstudent_status', 'id' => 'status_id', 'fields' => ['status_name', 'status_desc', 'is_active'], 'order' => 'status_id'],
    ];
}

function references(PDO $db): void
{
    current_account($db);
    $query = function (string $table, string $sql) use ($db): array { return table_present($db, $table) ? $db->query($sql)->fetchAll() : []; };
    respond([
        'active_academic_year' => active_year($db),
        'academic_years' => $query('tblacademic_years', 'SELECT acayearid id, ay label FROM tblacademic_years ORDER BY CAST(ay AS UNSIGNED), ay'),
        'grades' => $query('tblgradelevel', 'SELECT gradeid id, grade_level_desc label FROM tblgradelevel ORDER BY grade_level_desc'),
        'levels' => $query('tbllevels', 'SELECT levelid id, level_code label, sort_order FROM tbllevels ORDER BY sort_order, level_code'),
        'schedules' => $query('tblschedules', 'SELECT scheduleid id, schedule_name label, sort_order, is_active FROM tblschedules ORDER BY sort_order, schedule_name'),
        'sections' => $query('tblsectioning', 'SELECT secid id, gradeid, sec_name label FROM tblsectioning ORDER BY gradeid, sec_name'),
        'statuses' => $query('tblstudent_status', 'SELECT status_id id, status_name label, status_desc, is_active FROM tblstudent_status ORDER BY status_id'),
    ]);
}

function reference_rows(PDO $db, string $resource): void
{
    current_account($db); $map = reference_definitions();
    if (!isset($map[$resource])) fail('Unknown reference resource.', 404);
    $def = $map[$resource]; need_tables($db, [$def['table']]);
    respond($db->query("SELECT * FROM `{$def['table']}` ORDER BY {$def['order']}")->fetchAll());
}

function save_reference(PDO $db, string $resource, ?int $id = null): void
{
    current_account($db, ['Administrator']); $map = reference_definitions();
    if (!isset($map[$resource])) fail('Unknown reference resource.', 404);
    $def = $map[$resource]; need_tables($db, [$def['table']]); $body = input(); $values = [];
    foreach ($def['fields'] as $field) if (array_key_exists($field, $body)) $values[$field] = is_string($body[$field]) ? trim($body[$field]) : $body[$field];
    if ($values === []) fail('At least one valid field is required.', 422);
    foreach (['ay','grade_level_desc','level_code','schedule_name','sec_name','status_name'] as $required) if (array_key_exists($required, $values) && $values[$required] === '') fail('Labels cannot be empty.', 422);
    $creating = $id === null;
    try {
        if ($creating) {
            $columns = array_keys($values);
            $db->prepare("INSERT INTO `{$def['table']}` (`" . implode('`,`', $columns) . '`) VALUES (:' . implode(',:', $columns) . ')')->execute($values);
            $id = (int)$db->lastInsertId();
        } else {
            $set = implode(', ', array_map(function (string $field): string { return "`{$field}` = :{$field}"; }, array_keys($values)));
            $values['_id'] = $id;
            $db->prepare("UPDATE `{$def['table']}` SET {$set} WHERE `{$def['id']}` = :_id")->execute($values);
        }
    } catch (PDOException $e) { if ((string)$e->getCode() === '23000') fail('That value already exists or is in use.', 409); throw $e; }
    respond(['id' => $id], $creating ? 201 : 200);
}

function delete_reference(PDO $db, string $resource, int $id): void
{
    current_account($db, ['Administrator']); $map = reference_definitions();
    if (!isset($map[$resource])) fail('Unknown reference resource.', 404);
    $def = $map[$resource]; need_tables($db, [$def['table']]);
    try { $statement = $db->prepare("DELETE FROM `{$def['table']}` WHERE `{$def['id']}` = :id"); $statement->execute(['id' => $id]); }
    catch (PDOException $e) { if ((string)$e->getCode() === '23000') fail('This record is currently in use.', 409); throw $e; }
    if ($statement->rowCount() === 0) fail('Record not found.', 404); respond(['deleted' => true]);
}

function set_active_year(PDO $db): void
{
    current_account($db, ['Administrator']); need_tables($db, ['tblacademic_years', 'tblsettings']);
    $id = (int)(input()['academic_year_id'] ?? 0);
    $check = $db->prepare('SELECT COUNT(*) FROM tblacademic_years WHERE acayearid = :id'); $check->execute(['id' => $id]);
    if ($id < 1 || (int)$check->fetchColumn() === 0) fail('Select a valid academic year.', 422);
    if ((int)$db->query('SELECT COUNT(*) FROM tblsettings')->fetchColumn() > 0) $db->prepare('UPDATE tblsettings SET academic_year = :id ORDER BY setid DESC LIMIT 1')->execute(['id' => $id]);
    else $db->prepare('INSERT INTO tblsettings (academic_year) VALUES (:id)')->execute(['id' => $id]);
    respond(active_year($db));
}
