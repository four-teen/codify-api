<?php
declare(strict_types=1);

function account_rows(PDO $db): void
{
    current_account($db, ['Administrator']); need_tables($db, ['tblaccounts']);
    respond($db->query('SELECT acc_id, fullname, employee_id, username, role, is_active, last_login, created_at, updated_at FROM tblaccounts ORDER BY fullname, username')->fetchAll());
}

function save_account(PDO $db, ?int $id = null): void
{
    $current = current_account($db, ['Administrator']); need_tables($db, ['tblaccounts']); $body = input();
    $name = trim((string)($body['fullname'] ?? '')); $employee = trim((string)($body['employee_id'] ?? '')); $username = trim((string)($body['username'] ?? '')); $password = (string)($body['password'] ?? '');
    $role = ($body['role'] ?? 'User') === 'Administrator' ? 'Administrator' : 'User'; $active = isset($body['is_active']) ? ((bool)$body['is_active'] ? 1 : 0) : 1;
    if ($name === '' || $username === '' || string_length($name) > 100 || string_length($username) > 50 || ($id === null && strlen($password) < 8)) fail('Full name, username, and an initial password of at least 8 characters are required.', 422);
    if ($id === (int)$current['acc_id'] && $active === 0) fail('You cannot deactivate your own account.', 422);
    try {
        if ($id === null) {
            $db->prepare('INSERT INTO tblaccounts (fullname, employee_id, username, password_hash, role, is_active, created_at, updated_at) VALUES (:name,:employee,:username,:password,:role,:active,NOW(),NOW())')->execute(['name'=>$name,'employee'=>$employee?:null,'username'=>$username,'password'=>password_hash($password,PASSWORD_DEFAULT),'role'=>$role,'active'=>$active]);
            $id = (int)$db->lastInsertId();
        } else {
            $sql = 'UPDATE tblaccounts SET fullname=:name, employee_id=:employee, username=:username, role=:role, is_active=:active, updated_at=NOW()';
            $params = ['name'=>$name,'employee'=>$employee?:null,'username'=>$username,'role'=>$role,'active'=>$active,'id'=>$id];
            if ($password !== '') { if (strlen($password) < 8) fail('New passwords must contain at least 8 characters.', 422); $sql .= ', password_hash=:password'; $params['password'] = password_hash($password,PASSWORD_DEFAULT); }
            $sql .= ' WHERE acc_id=:id'; $db->prepare($sql)->execute($params);
        }
    } catch (PDOException $e) { if ((string)$e->getCode()==='23000') fail('That username is already in use.',409); throw $e; }
    respond(['id'=>$id]);
}

function delete_account(PDO $db, int $id): void
{
    $current=current_account($db,['Administrator']); if ($id===(int)$current['acc_id']) fail('You cannot delete your own account.',422);
    $statement=$db->prepare('DELETE FROM tblaccounts WHERE acc_id=:id'); $statement->execute(['id'=>$id]); if(!$statement->rowCount()) fail('Account not found.',404); respond(['deleted'=>true]);
}

function system_settings(PDO $db): void
{
    current_account($db); $config=table_present($db,'tblconfig')?($db->query('SELECT * FROM tblconfig ORDER BY configid LIMIT 1')->fetch()?:[]):[];
    respond(['config'=>$config,'active_academic_year'=>active_year($db),'sms'=>['configured'=>(string)env('SEMAPHORE_API_KEY','')!=='','sender_name'=>(string)env('SEMAPHORE_SENDER_NAME','')],'system'=>['api_version'=>'1.0.0','php_version'=>PHP_VERSION,'environment'=>env('APP_ENV','production')]]);
}

function update_settings(PDO $db): void
{
    current_account($db,['Administrator']); need_tables($db,['tblconfig']); $body=input();
    $name=trim((string)($body['systemname']??'Lexora')); $copyright=trim((string)($body['systemcopyright']??'')); $version=trim((string)($body['systemversion']??'1.0'));
    if($name===''||string_length($name)>50||string_length($copyright)>80||string_length($version)>15) fail('System settings exceed their allowed lengths.',422);
    $id=(int)$db->query('SELECT configid FROM tblconfig ORDER BY configid LIMIT 1')->fetchColumn();
    if($id>0) $db->prepare('UPDATE tblconfig SET systemname=:name,systemcopyright=:copyright,systemversion=:version WHERE configid=:id')->execute(['name'=>$name,'copyright'=>$copyright,'version'=>$version,'id'=>$id]);
    else { $db->prepare('INSERT INTO tblconfig (systemname,systemcopyright,systemversion) VALUES (:name,:copyright,:version)')->execute(['name'=>$name,'copyright'=>$copyright,'version'=>$version]); $id=(int)$db->lastInsertId(); }
    respond(['configid'=>$id,'systemname'=>$name,'systemcopyright'=>$copyright,'systemversion'=>$version]);
}

function send_sms(PDO $db): void
{
    current_account($db,['Administrator']); need_tables($db,['tblstudents']); $body=input(); $student=(int)($body['student_id']??0); $message=trim((string)($body['message']??''));
    if($student<1||$message===''||string_length($message)>1000) fail('Student and a message of at most 1000 characters are required.',422);
    $statement=$db->prepare('SELECT active_mobile_number FROM tblstudents WHERE stud_auto=:id'); $statement->execute(['id'=>$student]); $number=trim((string)$statement->fetchColumn());
    if($number==='') fail('The student has no active mobile number.',422); $key=(string)env('SEMAPHORE_API_KEY',''); if($key==='') fail('Semaphore SMS is not configured.',503); if(!function_exists('curl_init')) fail('The cURL extension is required.',503);
    $payload=['apikey'=>$key,'number'=>$number,'message'=>$message]; $sender=trim((string)env('SEMAPHORE_SENDER_NAME','')); if($sender!=='')$payload['sendername']=$sender;
    $curl=curl_init('https://api.semaphore.co/api/v4/messages'); curl_setopt_array($curl,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>http_build_query($payload),CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>30,CURLOPT_HTTPHEADER=>['Content-Type: application/x-www-form-urlencoded']]);
    $response=(string)curl_exec($curl); $status=(int)curl_getinfo($curl,CURLINFO_HTTP_CODE); $error=curl_error($curl); curl_close($curl);
    if($error!==''||$status<200||$status>=300) fail('Semaphore rejected the SMS request.',502,['provider_status'=>$status]); respond(['sent'=>true,'recipient'=>$number,'provider_response'=>json_decode($response,true)]);
}

function import_students(PDO $db): void
{
    current_account($db,['Administrator']); need_tables($db,['tblstudents']);
    if(!isset($_FILES['file'])||!is_array($_FILES['file'])) fail('A CSV, XLS, or XLSX file is required.',422); $file=$_FILES['file'];
    if((int)($file['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK||(int)($file['size']??0)>10*1024*1024) fail('The import failed or exceeds 10 MB.',422);
    $name=strtolower((string)($file['name']??'')); $temporary=(string)($file['tmp_name']??''); $rows=[];
    if(substr($name,-4)==='.csv'){ $handle=fopen($temporary,'rb'); if(!$handle)fail('The CSV file could not be opened.',422); while(($row=fgetcsv($handle))!==false)$rows[]=$row; fclose($handle); }
    elseif(preg_match('/\.xlsx?$/',$name)){ $autoload=dirname(__DIR__).'/vendor/autoload.php'; if(!is_file($autoload))fail('Excel import requires Composer dependencies on the API server.',503); require_once $autoload; $rows=\PhpOffice\PhpSpreadsheet\IOFactory::load($temporary)->getActiveSheet()->toArray(null,true,true,false); }
    else fail('Only CSV, XLS, and XLSX files are accepted.',422);
    if(count($rows)<2)fail('The import contains no student rows.',422);
    $headers=array_map(function($value):string{return strtolower(trim((string)preg_replace('/[^a-z0-9]+/i','_',(string)$value),'_'));},array_shift($rows));
    $aliases=['student_id'=>'studentid','learner_id'=>'studentid','lrn'=>'studentid','first_name'=>'firstname','middle_name'=>'middlename','last_name'=>'lastname','mobile'=>'active_mobile_number','mobile_number'=>'active_mobile_number','birth_date'=>'dob','date_of_birth'=>'dob'];
    $headers=array_map(function(string $header)use($aliases):string{return $aliases[$header]??$header;},$headers); foreach(['studentid','firstname','lastname']as$required)if(!in_array($required,$headers,true))fail('Required columns: studentid, firstname, lastname.',422);
    $year=active_year($db); $inserted=0;$updated=0;$skipped=[];
    $sql='INSERT INTO tblstudents (studentid,firstname,middlename,lastname,active_mobile_number,dob,status,ay,created_at) VALUES (:studentid,:firstname,:middlename,:lastname,:mobile,:dob,:status,:year,NOW()) ON DUPLICATE KEY UPDATE firstname=VALUES(firstname),middlename=VALUES(middlename),lastname=VALUES(lastname),active_mobile_number=VALUES(active_mobile_number),dob=VALUES(dob)'; $save=$db->prepare($sql);
    foreach($rows as$index=>$row){$row=array_pad($row,count($headers),null);$record=array_combine($headers,array_slice($row,0,count($headers)))?:[];$sid=trim((string)($record['studentid']??''));$first=trim((string)($record['firstname']??''));$last=trim((string)($record['lastname']??''));if($sid===''||$first===''||$last===''){$skipped[]=['row'=>$index+2,'reason'=>'Missing student ID, first name, or last name'];continue;}$exists=$db->prepare('SELECT COUNT(*) FROM tblstudents WHERE studentid=:id');$exists->execute(['id'=>$sid]);$was=(int)$exists->fetchColumn()>0;try{$save->execute(['studentid'=>$sid,'firstname'=>$first,'middlename'=>trim((string)($record['middlename']??''))?:null,'lastname'=>$last,'mobile'=>trim((string)($record['active_mobile_number']??''))?:null,'dob'=>trim((string)($record['dob']??''))?:null,'status'=>max(1,(int)($record['status']??1)),'year'=>(string)$year['id']]);$was?$updated++:$inserted++;}catch(PDOException$e){$skipped[]=['row'=>$index+2,'reason'=>'Invalid or conflicting data'];}}
    respond(['inserted'=>$inserted,'updated'=>$updated,'skipped'=>$skipped]);
}
