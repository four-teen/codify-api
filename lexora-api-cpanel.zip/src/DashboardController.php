<?php
declare(strict_types=1);

function dashboard(PDO $db): void
{
    current_account($db);
    $year = active_year($db);
    $yearId = (int)$year['id'];
    $studentCount = 0;
    if (table_present($db, 'tblstudent_enrollments') && $yearId > 0) {
        $statement = $db->prepare('SELECT COUNT(DISTINCT stud_auto) FROM tblstudent_enrollments WHERE ayid = :year');
        $statement->execute(['year' => $yearId]);
        $studentCount = (int)$statement->fetchColumn();
    } elseif (table_present($db, 'tblstudents')) {
        $studentCount = (int)$db->query('SELECT COUNT(*) FROM tblstudents')->fetchColumn();
    }
    $families = table_present($db, 'tblfamilies') ? (int)$db->query('SELECT COUNT(*) FROM tblfamilies')->fetchColumn() : 0;
    $activeStudents = $studentCount; $newThisMonth = 0; $withBalance = 0; $levels = [];
    if (table_present($db, 'tblstudent_enrollments') && $yearId > 0) {
        $activeSql = table_present($db,'tblstudent_status')
            ? 'SELECT COUNT(DISTINCT e.stud_auto) FROM tblstudent_enrollments e LEFT JOIN tblstudent_status st ON st.status_id=e.status WHERE e.ayid=:year AND (st.status_name IS NULL OR LOWER(st.status_name) IN ("active","enrolled","new"))'
            : 'SELECT COUNT(DISTINCT e.stud_auto) FROM tblstudent_enrollments e WHERE e.ayid=:year';
        $statement = $db->prepare($activeSql);
        $statement->execute(['year'=>$yearId]); $activeStudents=(int)$statement->fetchColumn();
        $statement = $db->prepare('SELECT COUNT(DISTINCT stud_auto) FROM tblstudent_enrollments WHERE ayid=:year AND enroll_date>=DATE_FORMAT(CURDATE(),"%Y-%m-01")');
        $statement->execute(['year'=>$yearId]); $newThisMonth=(int)$statement->fetchColumn();
        if(table_present($db,'tbllevels')){$statement=$db->prepare('SELECT COALESCE(l.level_code,"Unassigned") label,COUNT(DISTINCT e.stud_auto) total FROM tblstudent_enrollments e LEFT JOIN tbllevels l ON l.levelid=e.levelid WHERE e.ayid=:year GROUP BY e.levelid,l.level_code ORDER BY l.sort_order,l.level_code');$statement->execute(['year'=>$yearId]);$levels=$statement->fetchAll();}
    }
    $today = 0.0; $month = 0.0; $transactions = 0; $recent = []; $monthly = [];
    if (table_present($db, 'tblpayments_history')) {
        $params = ['year' => $yearId];
        $statement = $db->prepare('SELECT COALESCE(SUM(CASE WHEN DATE(date_paid) = CURDATE() THEN amount ELSE 0 END),0) today_amount, COALESCE(SUM(CASE WHEN DATE_FORMAT(date_paid, "%Y-%m") = DATE_FORMAT(CURDATE(), "%Y-%m") THEN amount ELSE 0 END),0) month_amount, COUNT(DISTINCT trans_number) transaction_count FROM tblpayments_history WHERE ayid = :year');
        $statement->execute($params); $totals = $statement->fetch();
        $today = (float)$totals['today_amount']; $month = (float)$totals['month_amount']; $transactions = (int)$totals['transaction_count'];
        $join = table_present($db, 'tblstudents') ? 'LEFT JOIN tblstudents s ON s.studentid = ph.studentid' : '';
        $name = table_present($db, 'tblstudents') ? "MIN(TRIM(CONCAT(s.firstname, ' ', s.lastname)))" : 'MIN(ph.studentid)';
        $statement = $db->prepare("SELECT ph.trans_number, MIN(ph.date_paid) date_paid, MIN(ph.studentid) studentid, {$name} student_name, SUM(ph.amount) amount FROM tblpayments_history ph {$join} WHERE ph.ayid = :year GROUP BY ph.trans_number ORDER BY date_paid DESC LIMIT 8");
        $statement->execute($params); $recent = $statement->fetchAll();
        $statement = $db->prepare('SELECT DATE_FORMAT(date_paid, "%Y-%m") period, SUM(amount) amount FROM tblpayments_history WHERE ayid = :year AND date_paid >= DATE_SUB(CURDATE(), INTERVAL 5 MONTH) GROUP BY DATE_FORMAT(date_paid, "%Y-%m") ORDER BY period');
        $statement->execute($params); $monthly = $statement->fetchAll();
    }
    $statuses = [];
    if (table_present($db, 'tblstudents') && table_present($db, 'tblstudent_status')) {
        $statuses = $db->query('SELECT st.status_name label, COUNT(s.stud_auto) total FROM tblstudent_status st LEFT JOIN tblstudents s ON s.status = st.status_id GROUP BY st.status_id, st.status_name ORDER BY st.status_id')->fetchAll();
    }
    respond([
        'active_academic_year' => $year,
        'metrics' => ['students' => $studentCount, 'active_students'=>$activeStudents, 'new_this_month'=>$newThisMonth, 'with_balance'=>$withBalance, 'families' => $families, 'transactions' => $transactions, 'today_collections' => $today, 'month_collections' => $month],
        'recent_transactions' => $recent, 'monthly_collections' => $monthly, 'status_breakdown' => $statuses, 'learning_levels'=>$levels,
        'modules' => ['payments' => table_present($db, 'tblpayments') && table_present($db, 'tblpayments_history'), 'sections' => table_present($db, 'tblsectioning'), 'families' => table_present($db, 'tblfamilies')],
    ]);
}
