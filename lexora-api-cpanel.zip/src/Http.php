<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/config/env.php';

function cors(): void
{
    $origin = (string)($_SERVER['HTTP_ORIGIN'] ?? '');
    $allowed = array_values(array_filter(array_map('trim', explode(',', (string)env('FRONTEND_ORIGINS', '')))));
    $accepted = $origin !== '' && in_array($origin, $allowed, true);
    if ($accepted) {
        header('Access-Control-Allow-Origin: ' . $origin);
        header('Vary: Origin');
        header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
        header('Access-Control-Allow-Headers: Authorization, Content-Type, Accept');
        header('Access-Control-Max-Age: 86400');
    }
    if (strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET')) === 'OPTIONS') {
        http_response_code($accepted ? 204 : 403);
        exit;
    }
}

function respond($data, int $status = 200, array $meta = []): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    header('X-Content-Type-Options: nosniff');
    $payload = ['data' => $data];
    if ($meta !== []) $payload['meta'] = $meta;
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function fail(string $message, int $status = 400, array $details = []): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    header('X-Content-Type-Options: nosniff');
    $payload = ['error' => $message];
    if ($details !== []) $payload['details'] = $details;
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function input(): array
{
    if (strpos(strtolower((string)($_SERVER['CONTENT_TYPE'] ?? '')), 'application/json') === false) return $_POST;
    $decoded = json_decode((string)file_get_contents('php://input'), true);
    if (!is_array($decoded)) fail('A valid JSON request body is required.', 400);
    return $decoded;
}

function route_path(): string
{
    $path = parse_url((string)($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH) ?: '/';
    $bases = [];
    $configured = parse_url((string)env('APP_URL', ''), PHP_URL_PATH);
    if (is_string($configured) && $configured !== '' && $configured !== '/') $bases[] = rtrim($configured, '/');
    $scriptBase = rtrim(str_replace('\\', '/', dirname((string)($_SERVER['SCRIPT_NAME'] ?? ''))), '/');
    if ($scriptBase !== '' && $scriptBase !== '.' && $scriptBase !== '/') $bases[] = $scriptBase;
    usort($bases, function (string $left, string $right): int { return strlen($right) <=> strlen($left); });
    foreach (array_unique($bases) as $base) {
        if ($path === $base || strpos($path, $base . '/') === 0) {
            $path = substr($path, strlen($base)) ?: '/';
            break;
        }
    }
    if ($path === '/index.php') $path = '/';
    elseif (strpos($path, '/index.php/') === 0) $path = substr($path, strlen('/index.php')) ?: '/';
    return '/' . ltrim(rtrim($path, '/') ?: '/', '/');
}

function bearer(): string
{
    $header = (string)($_SERVER['HTTP_AUTHORIZATION'] ?? '');
    if ($header === '' && function_exists('apache_request_headers')) {
        $headers = apache_request_headers();
        $header = (string)($headers['Authorization'] ?? $headers['authorization'] ?? '');
    }
    return preg_match('/^Bearer\s+(.+)$/i', $header, $matches) ? trim($matches[1]) : '';
}

function request_ip(): string { return substr((string)($_SERVER['REMOTE_ADDR'] ?? 'unknown'), 0, 45); }
function string_length(string $value): int { return function_exists('mb_strlen') ? mb_strlen($value) : strlen($value); }
