<?php
declare(strict_types=1);

function login(PDO $db): void
{
    need_tables($db, ['tblaccounts']);
    guard_login_attempts();
    $body = input();
    $username = trim((string)($body['username'] ?? ''));
    $password = (string)($body['password'] ?? '');
    if ($username === '' || $password === '') fail('Username and password are required.', 422);
    $statement = $db->prepare('SELECT acc_id, fullname, employee_id, username, password_hash, role, is_active, last_login FROM tblaccounts WHERE username = :username LIMIT 1');
    $statement->execute(['username' => $username]);
    $account = $statement->fetch();
    $valid = $account && (int)$account['is_active'] === 1 && password_verify($password, (string)$account['password_hash']);
    if (!$valid) { login_failed(); fail('Invalid username or password.', 401); }
    login_cleared();
    $db->prepare('UPDATE tblaccounts SET last_login = NOW() WHERE acc_id = :id')->execute(['id' => $account['acc_id']]);
    unset($account['password_hash']);
    $account['last_login'] = date('Y-m-d H:i:s');
    $token = token_for($account);
    respond(['account' => $account, 'access_token' => $token['access_token'], 'token_type' => 'Bearer', 'expires_at' => $token['expires_at']]);
}

function me(PDO $db): void { respond(current_account($db)); }
