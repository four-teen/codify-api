<?php
declare(strict_types=1);

function table_present(PDO $db, string $table): bool
{
    static $cache = [];
    if (array_key_exists($table, $cache)) return $cache[$table];
    $statement = $db->prepare('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = :table');
    $statement->execute(['table' => $table]);
    return $cache[$table] = (int)$statement->fetchColumn() > 0;
}

function column_present(PDO $db, string $table, string $column): bool
{
    static $cache = [];
    $key = $table . '.' . $column;
    if (array_key_exists($key, $cache)) return $cache[$key];
    $statement = $db->prepare('SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = :table AND column_name = :column');
    $statement->execute(['table' => $table, 'column' => $column]);
    return $cache[$key] = (int)$statement->fetchColumn() > 0;
}

function need_tables(PDO $db, array $tables): void
{
    $missing = [];
    foreach ($tables as $table) if (!table_present($db, $table)) $missing[] = $table;
    if ($missing !== []) fail('This Kumon module is not installed in the current database.', 503, ['missing_tables' => $missing]);
}

function active_year(PDO $db): array
{
    if (!table_present($db, 'tblacademic_years')) return ['id' => 0, 'label' => 'Not configured'];
    $id = 0;
    if (table_present($db, 'tblsettings')) $id = (int)$db->query('SELECT academic_year FROM tblsettings ORDER BY setid DESC LIMIT 1')->fetchColumn();
    $statement = $db->prepare('SELECT acayearid AS id, ay AS label FROM tblacademic_years WHERE acayearid = :id LIMIT 1');
    $statement->execute(['id' => $id]);
    $year = $statement->fetch();
    if ($year) return $year;
    return $db->query('SELECT acayearid AS id, ay AS label FROM tblacademic_years ORDER BY acayearid DESC LIMIT 1')->fetch() ?: ['id' => 0, 'label' => 'Not configured'];
}
