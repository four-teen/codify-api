<?php
declare(strict_types=1);

function kumon_load_env(string $filename): void
{
    if (!is_readable($filename)) return;
    $lines = file($filename, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if (!is_array($lines)) return;
    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '' || strpos($line, '#') === 0 || strpos($line, '=') === false) continue;
        list($key, $value) = array_map('trim', explode('=', $line, 2));
        if ($key === '' || getenv($key) !== false) continue;
        $value = trim($value, "\"'");
        putenv($key . '=' . $value);
        $_ENV[$key] = $value;
    }
}

kumon_load_env(dirname(__DIR__) . '/.env');

function env(string $key, ?string $fallback = null): ?string
{
    $value = getenv($key);
    return $value === false ? $fallback : $value;
}

function env_flag(string $key, bool $fallback = false): bool
{
    $value = env($key);
    return $value === null ? $fallback : filter_var($value, FILTER_VALIDATE_BOOLEAN);
}
