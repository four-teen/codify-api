-- Keep the existing database and tables; update only the old default product label.
UPDATE `tblconfig`
SET `systemname` = 'Lexora',
    `systemcopyright` = CASE
      WHEN `systemcopyright` IN ('Kumon PH', 'Kumon PH 2026') THEN 'Lexora 2026'
      ELSE `systemcopyright`
    END
WHERE `systemname` = 'Kumon PH';
