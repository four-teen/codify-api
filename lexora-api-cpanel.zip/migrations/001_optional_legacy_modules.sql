-- Lexora API compatibility tables
-- Safe for an existing kumonph_db: this migration only creates missing tables.

CREATE TABLE IF NOT EXISTS `tblsectioning` (
  `secid` int(11) NOT NULL AUTO_INCREMENT,
  `gradeid` int(11) DEFAULT NULL,
  `sec_name` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`secid`),
  UNIQUE KEY `uq_tblsectioning_grade_section` (`gradeid`, `sec_name`),
  KEY `idx_tblsectioning_gradeid` (`gradeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `tblpayments` (
  `payid` int(11) NOT NULL AUTO_INCREMENT,
  `paydescription` varchar(100) NOT NULL,
  `pay_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `charge_scope` varchar(20) NOT NULL DEFAULT 'student',
  `pay_ay` int(11) NOT NULL,
  PRIMARY KEY (`payid`),
  UNIQUE KEY `uq_tblpayments_year_description` (`pay_ay`, `paydescription`),
  KEY `idx_tblpayments_year` (`pay_ay`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `tblpayments_history` (
  `payhist_id` int(11) NOT NULL AUTO_INCREMENT,
  `studentid` varchar(50) NOT NULL,
  `family_id` int(11) DEFAULT NULL,
  `ayid` int(11) NOT NULL,
  `payid` int(11) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `date_paid` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `trans_number` varchar(50) NOT NULL,
  PRIMARY KEY (`payhist_id`),
  KEY `idx_payhist_student_year` (`studentid`, `ayid`),
  KEY `idx_payhist_family_id` (`family_id`),
  KEY `idx_payhist_payid` (`payid`),
  KEY `idx_payhist_trans_number` (`trans_number`),
  KEY `idx_payhist_date_paid` (`date_paid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
