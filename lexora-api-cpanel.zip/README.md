# Lexora API

Secured PHP JSON API for the Lexora learning center application using the existing `kumonph_db` database. This is the only module that connects to MySQL. The sibling `lexora` project is the static Vite frontend for Vercel.

## Local

With Vertrigo serving `C:\VertrigoServ\www`, the API base URL is:

```text
http://localhost/lexora-api
```

The included local `.env` uses `kumonph_db`. Verify `http://localhost/lexora-api/health` before starting the frontend.

## cPanel

Upload this folder to the `lexora-api` directory below the document root for `api.sksu-oracle.com`. Create a production `.env` from `.env.example`, use the cPanel-prefixed database name/user, create a unique `APP_KEY`, and set the exact Vercel origin in `FRONTEND_ORIGINS`.

The production database name is `nshft34_lexora_db`. Set its assigned cPanel database username and password in the production `.env`.

Give PHP write access to `storage/cache` and `storage/uploads`. Run `composer install --no-dev --optimize-autoloader` when XLS/XLSX imports are required. CSV imports do not require Composer.

The API never creates or migrates business tables during requests. Optional modules return HTTP 503 with `details.missing_tables` when their legacy tables are not installed.

If `tblsectioning`, `tblpayments`, or `tblpayments_history` is absent from an older database, import `migrations/001_optional_legacy_modules.sql` once in phpMyAdmin. It uses `CREATE TABLE IF NOT EXISTS`, so existing tables and records are not replaced.

Import `migrations/002_lexora_brand.sql` once to change the existing default system label from Kumon PH to Lexora without renaming the database.

## Security

- Exact-origin CORS allowlist
- Expiring signed Bearer tokens
- Login throttling
- Prepared SQL statements
- Administrator role enforcement for mutations
- Upload type and size validation
- Protected storage and configuration paths
- Password verification accepts only hashes created by PHP's password API
