<?php
declare(strict_types=1);

require_once __DIR__.'/src/Http.php';
require_once __DIR__.'/config/database.php';
require_once __DIR__.'/src/Schema.php';
require_once __DIR__.'/src/Auth.php';
require_once __DIR__.'/src/AuthController.php';
require_once __DIR__.'/src/DashboardController.php';
require_once __DIR__.'/src/ReferenceController.php';
require_once __DIR__.'/src/StudentController.php';
require_once __DIR__.'/src/FamilyController.php';
require_once __DIR__.'/src/FinanceController.php';
require_once __DIR__.'/src/AdminController.php';

cors();$method=strtoupper((string)($_SERVER['REQUEST_METHOD']??'GET'));$path=route_path();
try{
    $db=database();
    if($method==='GET'&&($path==='/'||$path==='/health')){$db->query('SELECT 1');respond(['service'=>'Lexora API','status'=>'ok','database'=>'connected','version'=>'1.0.0']);}
    if($method==='POST'&&$path==='/api/auth/login')login($db);
    if($method==='GET'&&$path==='/api/auth/me')me($db);
    if($method==='GET'&&$path==='/api/dashboard')dashboard($db);
    if($method==='GET'&&$path==='/api/reference-data')references($db);
    if($method==='POST'&&$path==='/api/academic-years/active')set_active_year($db);
    if(preg_match('#^/api/references/([a-z-]+)$#',$path,$m)){if($method==='GET')reference_rows($db,$m[1]);if($method==='POST')save_reference($db,$m[1]);}
    if(preg_match('#^/api/references/([a-z-]+)/(\d+)$#',$path,$m)){if(in_array($method,['PATCH','PUT'],true))save_reference($db,$m[1],(int)$m[2]);if($method==='DELETE')delete_reference($db,$m[1],(int)$m[2]);}
    if($method==='GET'&&$path==='/api/students')student_rows($db);
    if($method==='POST'&&$path==='/api/students')create_student($db);
    if(preg_match('#^/api/students/(\d+)$#',$path,$m)){if($method==='GET')student_details($db,(int)$m[1]);if(in_array($method,['PATCH','PUT'],true))update_student($db,(int)$m[1]);if($method==='DELETE')delete_student($db,(int)$m[1]);}
    if($method==='POST'&&preg_match('#^/api/students/(\d+)/enrollments$#',$path,$m))enroll_student($db,(int)$m[1]);
    if($method==='POST'&&preg_match('#^/api/students/(\d+)/image$#',$path,$m))upload_student_image($db,(int)$m[1]);
    if($method==='GET'&&preg_match('#^/api/student-images/([a-zA-Z0-9._-]+)$#',$path,$m))serve_student_image($db,rawurldecode($m[1]));
    if($method==='GET'&&$path==='/api/families')family_rows($db);
    if($method==='POST'&&$path==='/api/families')save_family($db);
    if(preg_match('#^/api/families/(\d+)$#',$path,$m)){if($method==='GET')family_details($db,(int)$m[1]);if(in_array($method,['PATCH','PUT'],true))save_family($db,(int)$m[1]);if($method==='DELETE')delete_family($db,(int)$m[1]);}
    if($method==='POST'&&preg_match('#^/api/families/(\d+)/members$#',$path,$m))add_family_member($db,(int)$m[1]);
    if($method==='DELETE'&&preg_match('#^/api/families/(\d+)/members/(\d+)$#',$path,$m))remove_family_member($db,(int)$m[1],(int)$m[2]);
    if($method==='GET'&&$path==='/api/fees')fee_rows($db);
    if($method==='POST'&&$path==='/api/fees')save_fee($db);
    if(preg_match('#^/api/fees/(\d+)$#',$path,$m)){if(in_array($method,['PATCH','PUT'],true))save_fee($db,(int)$m[1]);if($method==='DELETE')delete_fee($db,(int)$m[1]);}
    if($method==='GET'&&$path==='/api/transactions')transaction_rows($db);
    if($method==='POST'&&$path==='/api/transactions')create_transaction($db);
    if($method==='GET'&&preg_match('#^/api/transactions/([^/]+)/receipt$#',$path,$m))transaction_receipt($db,rawurldecode($m[1]));
    if($method==='DELETE'&&preg_match('#^/api/transactions/([^/]+)$#',$path,$m))delete_transaction($db,rawurldecode($m[1]));
    if($method==='GET'&&$path==='/api/collections')collections($db);
    if($method==='GET'&&$path==='/api/accounts')account_rows($db);
    if($method==='POST'&&$path==='/api/accounts')save_account($db);
    if(preg_match('#^/api/accounts/(\d+)$#',$path,$m)){if(in_array($method,['PATCH','PUT'],true))save_account($db,(int)$m[1]);if($method==='DELETE')delete_account($db,(int)$m[1]);}
    if($method==='GET'&&$path==='/api/settings')system_settings($db);
    if(in_array($method,['PATCH','PUT'],true)&&$path==='/api/settings')update_settings($db);
    if($method==='POST'&&$path==='/api/imports/students')import_students($db);
    if($method==='POST'&&$path==='/api/sms')send_sms($db);
    fail('Route not found.',404);
}catch(PDOException$e){error_log($e->getMessage());fail('Database request failed.',500,env_flag('APP_DEBUG')?['message'=>$e->getMessage()]:[]);}catch(Throwable$e){error_log($e->getMessage());fail('Unexpected server error.',500,env_flag('APP_DEBUG')?['message'=>$e->getMessage(),'file'=>$e->getFile(),'line'=>$e->getLine()]:[]);}
