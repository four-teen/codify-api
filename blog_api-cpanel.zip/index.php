<?php
declare(strict_types=1);

// cPanel entry point. The application remains in public/index.php so the same
// code also works locally at /blog_api/public under Vertrigo.
require __DIR__ . '/public/index.php';

