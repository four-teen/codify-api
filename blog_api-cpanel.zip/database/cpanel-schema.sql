-- Select the database you created in cPanel/phpMyAdmin before importing.
-- This file intentionally does not CREATE or USE a database because cPanel
-- database names normally include an account-specific prefix.

CREATE TABLE IF NOT EXISTS tblblogs (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    title VARCHAR(180) NOT NULL,
    message TEXT NOT NULL,
    author VARCHAR(100) NOT NULL DEFAULT 'Administrator',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    INDEX idx_tblblogs_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO tblblogs (title, message, author)
SELECT seed.title, seed.message, seed.author
FROM (
    SELECT 'Welcome to Oracle Notes' AS title,
           'This message is served by the PHP API from the cPanel MySQL database.' AS message,
           'Site Administrator' AS author
    UNION ALL
    SELECT 'Vercel is connected to cPanel',
           'The public Vercel frontend reads these records through api.sksu-oracle.com.',
           'Development Team'
    UNION ALL
    SELECT 'The API is ready',
           'PHP, MySQL, CORS, HTTPS, and the Vercel frontend now work as separate modules.',
           'Oracle Notes'
) AS seed
WHERE NOT EXISTS (SELECT 1 FROM tblblogs);

