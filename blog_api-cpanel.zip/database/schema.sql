CREATE DATABASE IF NOT EXISTS blogs_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE blogs_db;

CREATE TABLE IF NOT EXISTS tblblogs (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    title VARCHAR(180) NOT NULL,
    message TEXT NOT NULL,
    author VARCHAR(100) NOT NULL DEFAULT 'Administrator',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    INDEX idx_tblblogs_created_at (created_at)
) ENGINE=InnoDB;

INSERT INTO tblblogs (title, message, author)
SELECT seed.title, seed.message, seed.author
FROM (
    SELECT 'Welcome to Oracle Notes' AS title,
           'This is the first message served by the PHP API from the Vertrigo MySQL database.' AS message,
           'Site Administrator' AS author
    UNION ALL
    SELECT 'The frontend and API are connected',
           'The Vite frontend requests these records from blogs_db.tblblogs through a JSON API.',
           'Development Team'
    UNION ALL
    SELECT 'Ready for cPanel and Vercel',
           'Deploy PHP and MySQL on cPanel, then point the Vercel environment variable to the HTTPS API address.',
           'Oracle Notes'
) AS seed
WHERE NOT EXISTS (SELECT 1 FROM tblblogs);
