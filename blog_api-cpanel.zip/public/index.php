<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/src/http.php';
require_once dirname(__DIR__) . '/config/database.php';

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$base = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '')), '/');
if ($base !== '' && strpos($path, $base) === 0) {
    $path = substr($path, strlen($base)) ?: '/';
}
$path = rtrim($path, '/') ?: '/';

try {
    if ($method === 'GET' && ($path === '/' || $path === '/health')) {
        jsonResponse(['service' => 'Blog API', 'status' => 'ok']);
    }

    if ($method === 'GET' && $path === '/api/posts') {
        $posts = db()->query(
            'SELECT id, title, message, author, created_at, updated_at FROM tblblogs ORDER BY created_at DESC, id DESC'
        )->fetchAll();
        jsonResponse(['data' => $posts]);
    }

    if ($method === 'POST' && $path === '/api/posts') {
        $input = requestJson();
        $title = trim((string) ($input['title'] ?? ''));
        $message = trim((string) ($input['message'] ?? $input['body'] ?? ''));
        $author = trim((string) ($input['author'] ?? 'Guest Author'));

        if ($title === '' || textLength($title) > 180 || $message === '' || $author === '' || textLength($author) > 100) {
            jsonResponse(['error' => 'Title, message, and author are required and must fit their limits.'], 422);
        }

        $statement = db()->prepare(
            'INSERT INTO tblblogs (title, message, author) VALUES (:title, :message, :author)'
        );
        $statement->execute(['title' => $title, 'message' => $message, 'author' => $author]);
        $id = (int) db()->lastInsertId();

        $statement = db()->prepare(
            'SELECT id, title, message, author, created_at, updated_at FROM tblblogs WHERE id = :id'
        );
        $statement->execute(['id' => $id]);
        jsonResponse(['data' => $statement->fetch()], 201);
    }

    jsonResponse(['error' => 'Route not found.'], 404);
} catch (PDOException $exception) {
    error_log($exception->getMessage());
    $debug = filter_var(env('APP_DEBUG', 'false'), FILTER_VALIDATE_BOOLEAN);
    $response = ['error' => 'Database request failed.'];
    if ($debug) {
        $response['detail'] = $exception->getMessage();
    }
    jsonResponse($response, 500);
} catch (Throwable $exception) {
    error_log($exception->getMessage());
    jsonResponse(['error' => 'Unexpected server error.'], 500);
}
