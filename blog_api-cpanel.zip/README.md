# Blog API (PHP + MySQL)

This module is deployed to cPanel. The separate `blog_frontend` module is a static Vercel site and calls this API over HTTPS.

## Local setup

1. Copy `.env.example` to `.env` and use local MySQL credentials.
2. Import `database/schema.sql` in phpMyAdmin or with the MySQL command line. It creates `blogs_db.tblblogs` and three sample records.
3. Make Apache serve the `public` directory, or visit `http://localhost/blog_api/public` under Vertrigo.
4. Test `GET /health` and `GET /api/posts`.

PHP requirements: PHP 7.1+, PDO MySQL, Apache `mod_rewrite`.

## cPanel deployment

The current `api.sksu-oracle.com` document root can receive this entire module directly. The root `index.php` forwards requests to `public/index.php`, and the root `.htaccess` blocks browser access to `.env`, `config`, `database`, `src`, `public`, SQL, logs, and documentation.

1. Create a MySQL database and user in cPanel, grant the user all privileges, select that database in phpMyAdmin, and import `database/cpanel-schema.sql`. cPanel normally prefixes database/user names; put the exact names in `.env`.
2. Upload the contents of this module into the `api.sksu-oracle.com` document root. Create `.env` from `.env.cpanel.example` and insert the exact cPanel database values. Never commit or publicly share `.env`.
3. Set `APP_URL=https://api.sksu-oracle.com`.
4. Set `FRONTEND_ORIGINS=https://blogger-drab-three.vercel.app`. Add future frontend domains comma-separated with no trailing slash.
5. Enable SSL for the API subdomain and verify `https://api.sksu-oracle.com/health`.
6. Verify `https://api.sksu-oracle.com/api/posts`, then open the Vercel frontend.

## Endpoints

- `GET /health`
- `GET /api/posts`
- `POST /api/posts` with JSON: `{ "title": "Example", "message": "Post text", "author": "Your Name" }`

The POST endpoint is intentionally open for the connection demo. Add authentication and rate limiting before using it as a real administration endpoint.

## About hiding the private domain

Visitors only see the Vercel site in their address bar, but browser requests reveal the API hostname in developer tools. This is normal. CORS is access control for browsers, not a secrecy or authentication mechanism.
